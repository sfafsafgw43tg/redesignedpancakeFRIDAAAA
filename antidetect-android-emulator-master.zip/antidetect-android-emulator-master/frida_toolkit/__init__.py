"""Frida module initialization"""
