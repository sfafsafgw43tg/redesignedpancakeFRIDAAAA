"""Profiles module initialization"""
