"""GUI module initialization"""
